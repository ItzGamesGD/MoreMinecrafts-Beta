place template sky_tower:full_01 ~-24 ~ ~-24 none none 1.0 0 strict
